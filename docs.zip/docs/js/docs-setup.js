NG_DOCS={
  "sections": {
    "api": "Itesoft Awesome Docs"
  },
  "pages": [
    {
      "section": "api",
      "id": "SP.service:TranslationService",
      "shortName": "TranslationService",
      "type": "service",
      "moduleName": "SP",
      "shortDescription": "Service to load translation part that are needed for view rendering.",
      "keywords": "$q $translate $translatepartialloader api app avoid controller display function html javascript load my-first-translation-part my-second-translation-part needed problems rendering resolve resolver return route service sp superviseactivitycontroller templateurl translation translationpart translationservice view"
    }
  ],
  "apis": {
    "api": true
  },
  "__file": "_FAKE_DEST_/js/docs-setup.js",
  "__options": {
    "startPage": "/api",
    "scripts": [
      "js/marked.js",
      "js/dist/assets/lib/vendor.min.js",
      "js/dist/app/itesoft.debug.js"
    ],
    "styles": [
      "css/dist/assets/fonts/itesoft-bundle.min.css"
    ],
    "title": "Itesoft Awesome Docs",
    "html5Mode": false,
    "editExample": true,
    "navTemplate": false,
    "navContent": "",
    "navTemplateData": {},
    "loadDefaults": {
      "angular": false,
      "angularAnimate": false,
      "marked": true
    },
    "titleLink": "#/api"
  },
  "html5Mode": false,
  "editExample": true,
  "startPage": "/api",
  "scripts": [
    "js/marked.js",
    "js/dist/assets/lib/vendor.min.js",
    "js/dist/app/itesoft.debug.js"
  ],
  "styles": [
    "css/dist/assets/fonts/itesoft-bundle.min.css"
  ]
};